import ProductList from './ProductList';

export default ProductList;
